# Copyright 2011 Google Inc. All Rights Reserved.
# yuxue@google.com (Yuxue Jin)

# This file contains the functions used to fit a nonlinear functional form
# to the TV reach curve. The functional form may or may not have a knot.
# The function ForecastIncrementalGRPs fits both the model without a knot and
# the model with a knot at different places, and picks the best model. It
# extrapolates the reach curve and finds the delta GRPs to deliver the
# incremental reach on TV. It can also interpolate the curve to find the number
# of GRPs on TV to deliver the last few reach points equal to the incremental
# reach.
# 
# http://code.google.com/p/incremental-reach/
# contains the details on the model used in fitting the curve

# An example on how to use these functions.
## Fit a 3plus reach curve. The data points on the curve are
## alread pre-selected. 
## data("curve3plus")
## curve <- curve3plus
## reach.tv <- 36.89
## reach.combined <- 39.58
## result <-
##   ForecastIncrementalGRPs(curve, reach.tv = reach.tv,
##                           reach.combined = reach.combined,
##                           interpolate = TRUE)
## reach.proj <- seq(0, reach.combined, length = 200)
## grp.proj <- PredictGRP(reach.proj, result$knot, coef(result))
## PlotCurves(curve, reach.proj, grp.proj, reach.combined)
## # check if the residuals of the nls fit are uncorrelated
## acf(resid(result))

SelectDataPoints <- function(data.complete, num.points) {
  # Read in the reach curve and select data points on the reach curve that
  # are evenly spaced in terms of GRPs.
  # The number of data points is usually equal to the number of campaign days
  # The original reach curve, which has one data point for one TV spot,
  # is too "crowded" and auto-correlated for our purpose.  
  # Args:
  #   data.complete: a data frame with at least two columns, "grp" and "reach".
  #   num.points: the number of data points to select
  # Returns:
  #   data.selected: a data frame with the same columns as data.complete, but
  #                  only selected rows
  
  # the number of days in the campaign
  data.complete <- FormatCheck(data.complete)
  # Select data points that are evenly spaced out in terms of GRPs
  grp.grid <- seq(from = min(data.complete$grp),
                  to = max(data.complete$grp),
                  length = num.points)
  rows.selected <- c()
  for (i in 1 : num.points){
    row.id <- which.max(data.complete$grp >= grp.grid[i])
    rows.selected <- c(rows.selected, row.id)
  }
  data.selected <- data.complete[rows.selected, ]
  
  return(data.selected)
}


SetUpModel <- function(curve, knot, residuals.correlation) {
  # Generate the data frame and the formula used in the nls fit 
  # It adjusts for the correlation of residuals by
  # taking lag-1 difference in GRP and uses the difference as the dependent
  # variable in the nls fit.
  # Args:
  #   curve: a data frame with at least two columns, "reach" and "grp"
  #   knot: the knot in the model. NA means no knot is used.
  #   residuals.correlation: the correlation of the residuals used in
  #                          generating a new set of response variables 
  # Returns:
  #   curve.for.regression: the data frame to be used in the nls fit
  #   formula: the formula to be used in the nls fit

  # compute the lag-1 difference in grp, grp.ar will be used as the dependent
  # variable in fitting the nls model
  obs.last <- nrow(curve)
  grp.ar <- curve$grp[2 : obs.last] -
    residuals.correlation * curve$grp[1 : (obs.last - 1)]
  # make a new data frame, reach.prev is the reach on the previous day,
  # reach.curr is the reach on the current day
  curve.ar <- data.frame(reach.prev = curve$reach[1 : (obs.last-1)],
                         reach.curr = curve$reach[2 : obs.last],
                         grp.ar = grp.ar)
  curve.ar$reach.spline.curr <- GetSpline(curve.ar$reach.curr, knot)
  curve.ar$reach.spline.prev <- GetSpline(curve.ar$reach.prev, knot)
  curve.ar$residuals.correlation <- residuals.correlation
  
  # the fomula to fit the nonlinear curve with grp.ar as the dependent
  # variable
  if (is.na(knot)) {
    formula <- as.formula(grp.ar ~ b *
                          (1 / (a - reach.curr) -
                           residuals.correlation / (a - reach.prev) -
                           1 / a + residuals.correlation / a))
  } else {
    formula <- as.formula(grp.ar ~ b *
                          (1 / (a - reach.curr - c * reach.spline.curr) -
                           residuals.correlation / (a - reach.prev -
                                                    c * reach.spline.prev) -
                           1 / a + residuals.correlation / a))
  }
 
  return(list(curve.for.regression = curve.ar, formula = formula))
}

GetResidualsCorrelation <- function(residuals) {
  # Get the autocorrelation of the residuals. It is zero if there is no
  # auto-correlation. Otherwise, it is the coefficient of fitting an
  # AR(1) process.
  
  model.ar <- ar(residuals, order.max=1)
  if (model.ar$order == 0){
    residuals.correlation <- 0
  } else {
    residuals.correlation <- model.ar$ar[1]
  }
  return(residuals.correlation)
}

  
PredictGRP <- function(reach, knot, coef.estimates) {
  # Predict GRP for a given reach. If knot = NA, use the model without
  # a knot; otherwise, use the model with a knot.
  
  a.hat <- coef.estimates["a"]
  b.hat <- coef.estimates["b"]
  if (is.na(knot)) {
    grp.proj <- b.hat / pmax(0, a.hat - reach) -
                b.hat / a.hat
  } else {
    c.hat <- coef.estimates["c"]
    reach.spline <- GetSpline(reach, knot)
    grp.proj <- b.hat / pmax(0, a.hat - reach - c.hat * reach.spline) -
                b.hat / a.hat
  }
  return(grp.proj)
}

GetSpline <- function(x, knot) {
  # Return a cubic spline in x 
  # x could be a vector.
  if (is.na(knot)) {
    result <- NA
  } else {
    result <- ifelse(x >= knot, (x - knot)^3, 0)
  }
  return(result)
}

ComputeDeltaGRP <- function(coef.estimates, reach.combined, reach.tv, knot) {
  # Compute the delta GRP needed for TV reach to increase from reach.tv to
  # reach.combined
  if (any(coef.estimates < 0)) {
    delta.grp <- NA
  } else {
    grp.proj <- PredictGRP(reach.combined, knot, coef.estimates)
    grp.tv.predicted <- PredictGRP(reach.tv, knot, coef.estimates)
    delta.grp <- grp.proj - grp.tv.predicted
  }
  return(delta.grp)
}

GetConfidenceInterval <- function(coef.estimates, cov.mat, reach.combined,
                                   reach.tv, knot, level = 0.95, nsim = 5000) {
  # Generate the confidence interval of estimated delta GRPs
  # using simulation methods

  # Simulate coefficients based on a multinormal distribution
  # (central limit theorem)
  coef.simulated <- mvrnorm(n = nsim, mu = coef.estimates, Sigma = cov.mat)
  # Use the simulated coefficients to estimate delta GRPs
  delta.simulated <- apply(coef.simulated, 1, ComputeDeltaGRP,
                           reach.combined = reach.combined,
                           reach.tv = reach.tv,
                           knot = knot)
  ci.delta <- quantile(delta.simulated,
                       probs = c((1 - level) / 2, 1 - (1 - level) /2),
                       na.rm = T)
  return(list(ci = ci.delta, simulations = delta.simulated))
}

FormatCheck <- function(curve) {
  # check if the input argument, curve, contains the columns grp and reach
  # and the columns are non-negative
  
  # convert the column names into lower cases
  names(curve) <- tolower(names(curve))
  # the data frame that will be returned. It will be NULL if any of the
  # following conditions is met.
  curve.new <- curve
  for (col.name in c("grp", "reach")) {
    if (!is.element(col.name, names(curve))) {
      warning(sprintf("The input curve does not contain a column for %s.",
                   col.name))
      curve.new <- NULL
    } else if (!is.numeric(curve[, col.name])) {
      warning(sprintf("In the input curve, the column for %s must be numeric.",
                   col.name))
      curve.new <- NULL
    } else if (any(curve[, col.name] < 0)) {
      warning(sprintf("In the input curve, the column for %s has negative
                      values", col.name))
    }
  }
  return(curve.new)
}

ForecastIncrementalGRPs <- function(curve, reach.tv, reach.combined,
                                    interpolate = FALSE, 
                                    use.knot = TRUE, p.value.cutoff = 0.05,
                                    level = 0.95) {
  # Fit the model without a knot and models with knots to the reach curve;
  # Find the best knot and compare the model with the best knot with the model
  # without a knot using the likelihood ratio test.
  # Output the results of the model without a knot and the model with the
  # best knot.
  # Args:
  #   interpolate: if true, it will interpolate the actual curve and the fitted
  #                curves to find the number of GRPs that delivered the last few
  #                reach points on TV equal to the incremental reach
  #   use.knot: if false, it will only fit the model without a knot
  #   p.value.cutoff: the cutoff of the p value of the likelihood ratio
  #                   test to choose between the model without a knot and model
  #                   with a knot
  #   level: the level of the confidence interval of incremental GRPs
  # Returns:
  #   delta: Estimated additional TV GRPs needed to get the equivalent
  #          incremental reach
  #   ci: a vector of two elements. The confidence interval of delta.   
  #   coefficients: a numeric vector of coefficients of the model.
  #   knot: The knot used in the model. If no knot is used, it is NA. 
  #   limit: The limit of reach in the functional form.
  #   fitted.values: a numeric vector of fitted GRPs.
  #   rmse: the root mean squared error of fitting GRPs.
  #   residuals: the residuals of the nls fit.
  #   residuals.correlation: the auto-correlation of the residuals
  #                          from fitting AR(1) model.
  #   fit: the nls fit.
  #   delta.interpolate: GRPs needed to deliver the incremental
  #                      reach, obtained by interpolating the observed reach
  #                      curve.
  #   delta.interpolate.model: GRPs needed to deliver the incremental
  #                            reach, obtained by interpolating the fitted
  #                            reach curve.
  #   ci.interpolate: a numeric vector of two elements, the confidence interval
  #                   of delta.interpolate.model.
  
  # the rounding error allowed in comparing the total TV reach with the maximum
  # reach on the curve
  kRoundingTolerance <- 0.01
  # the threshold of the p value of estimated coefficient "c"
  kSignificance <- 0.05
  
  curve <- FormatCheck(curve)
  if (is.null(curve)) {
    warning("Format check of the input data frame fails.")
    return(NULL)
  }
  if (reach.combined < reach.tv) {
    warning("reach.combined should not be less than reach.tv.")
  }
  if (reach.tv < 0) {
    warning("reach.tv is negative.")
  }
  max.GRP.ID <- which.max(curve$grp)
  grp.maximal <- curve$grp[max.GRP.ID]
  reach.maximal <- curve$reach[max.GRP.ID]
  if (abs(reach.tv - reach.maximal) >  kRoundingTolerance) {
    warning("The end of the reach curve is not the same as TV total reach.")
  }
  a0 <- reach.maximal + 5
  b0 <- (a0 - reach.maximal ) * grp.maximal * a0 / reach.maximal
  c0 <- 0
  # fit an initial model to estimate the residuals correlation
  fit.temp <- nls(grp ~ b/(a - reach) - b/a,
                  start = list(a = a0, b = b0),
                  data = curve, control = list(maxiter = 400))
  residuals.correlation <- GetResidualsCorrelation(residuals(fit.temp))
  # try different models, with knots at different values and without a knot
  if (use.knot) {
    knots.to.try <- seq(max(0, reach.maximal - 1),
                        to = max(0, reach.maximal - 10),
                        by = -1)
    knots.to.try <- c(NA, knots.to.try)
  } else  {
    knots.to.try <- c(NA)
  }
  num.trials <- length(knots.to.try)
  rse.vec <- rep(0, num.trials)
  fit.list <- list()
  for (i in 1 : num.trials) {
    knot <- knots.to.try[i]
    result <- SetUpModel(curve, knot, residuals.correlation)
    curve.for.regression <- result$curve.for.regression
    formula <- result$formula
    if (is.na(knot)) {
      initials <- list(a = a0, b = b0)
    } else {
      initials <- list(a = a0, b = b0, c = c0)
    }
    # Use "try" so that the rest of the function can still execute
    # even if some of the nls fits run into errors.  
    fit <- try(nls(formula, start = initials,
               data = curve.for.regression, control = list(maxiter = 400)))
    if (class(fit) == "try-error") {
      rse.vec[i] <- Inf
    } else {
       grp.fitted <- PredictGRP(curve$reach, knot = knot,
                                coef.estimates = coef(fit))
      # residual standard error(root mean squared error)
      rse.vec[i] <- sqrt(mean((grp.fitted - curve$grp)^2))  
      if (!is.na(knot)) {
        # p value of the estimate for "c"
        pvalue <- summary(fit)$para["c", "Pr(>|t|)"]
        # If the model has a knot and the p value for "c" is not significant
        # or some of the esitmated coefficients are negative, this model is
        # not feasible and the rse for this model is set to Inf. 
        if (pvalue >= kSignificance | any(coef(fit) < 0)) {
          rse.vec[i] <- Inf
        }
      }
    }
    fit.list[[i]] <-  fit
  }
  ##############################################################################
  # the model without the knot
  fit.no.knot <- fit.list[[1]]
  # the index of the best model
  index.best <- 1
  ##############################################################################
  # Use the likelihood ratio test to choose between the model with the best
  # knot and the model without a knot
  if (use.knot) {
    index <- which.min(rse.vec[-1]) + 1
    fit.best.knot <- fit.list[[index]]
    if (is.finite(rse.vec[index])) {
      # the likelihood ratio test of the best model with a knot vs the model
      # without a knot. The two degrees of freedom come from the extra parameter
      # c and the fact we choose the best knot
      lk.test <- 1 - pchisq(2 * (logLik(fit.best.knot) - logLik(fit.no.knot)),
                            df = 2)
      if (lk.test <= p.value.cutoff) {
        index.best <- index
      }
    }
  }
  fit.best <- fit.list[[index.best]]
  knot.best <- knots.to.try[index.best]
  rse.best <- rse.vec[index.best]
  
  coef.best <- coef(fit.best)
  delta.grp <- ComputeDeltaGRP(coef.best, reach.combined,
                               reach.tv, knot = knot.best)
  grp.fitted <- PredictGRP(curve$reach, knot = knot.best,
                           coef.estimates = coef(fit.best))
  res.corr <- GetResidualsCorrelation(residuals(fit.best))
  cov.best <- vcov(fit.best)
  ci.best <- GetConfidenceInterval(coef.best, cov.best,
                                   reach.combined,
                                   reach.tv, knot = knot.best,
                                   level = level)$ci
  # the limit of the fitted function
  limit.best <- FindLimit(coef.best, knot.best)
  if (interpolate) {
    # interpolate based on the actual curve
    delta.interpolate <- InterpolateEstimate(curve, reach.tv,
                                             reach.combined)
    # interpolate based on the fitted curve, and its confidence interval
    reach.end <- reach.tv - (reach.combined - reach.tv)
    delta.interpolate.model <- ComputeDeltaGRP(coef.estimates = coef.best,
                                               reach.combined = reach.tv,
                                               reach.tv = reach.end,
                                               knot = knot.best)
    ci.interpolate.model <-
      GetConfidenceInterval(coef.best, cov.best,
                            reach.combined = reach.tv,
                            reach.tv = reach.end,
                            knot = knot.best, level = level)$ci
  } 
  output <- list(delta = delta.grp,
                 ci = ci.best,
                 coefficients = coef.best,
                 knot = knot.best,
                 limit = limit.best,
                 fitted.values = grp.fitted,
                 rmse = rse.best,
                 residuals = residuals(fit.best),
                 residuals.correlation = res.corr,
                 fit = fit.best)
                 
  if (interpolate) {
    output <- append(output,
                     list(delta.interpolate = delta.interpolate,
                          delta.interpolate.model = delta.interpolate.model,
                          ci.interpolate = ci.interpolate.model))
  }
  
  return(output)
}

Denominator <- function(reach, a, c, knot) {
  # Calculates the denominator of the model with a knot
  return(a - reach - c * GetSpline(reach, knot))
}


FindLimit <- function(coef.estimates, knot) {
  # Find the limit of the functional form.
  # If it does not have a knot, the limit is the estimated parameter a;
  # If it has a knot, the limit is solved by finding the value of reach that
  # makes the denominator <= 0
  
  if (is.na(knot)) {
    limit <- coef.estimates["a"]
  } else {
    result <- uniroot(Denominator, interval = c(0, coef.estimates['a']),
                      a = coef.estimates["a"], c = coef.estimates["c"],
                      knot = knot)
    limit <- result$root
  }
  return(limit)
}
 
 
PlotCurves <- function(curve, reach.proj, grp.proj, reach.combined,
                       xmax = NA){
  # Plots the fitted curve and the observed TV reach curves
  # Arg:
  #   curve: a data frame with two columns, "reach" and "grp". The column
  #          "reach" is the TV cumulative reach in percentage, and the column
  #          "grp" is the TV cumulative GRP. 
  #   reach.proj; a vector of reach values that are used to predict
  #               corresponding GRPs
  #   grp.proj: a vector of predicted GRPs; 
  #   reach.combined: the combined reach of TV and YouTube, in percentage
  #   xmax: the upper limit of the range of GRP the curve should be plotted

  curve <- FormatCheck(curve)
  grp.proj[is.infinite(grp.proj)] <- NA
  if (is.na(xmax)) {
    xlim <- c(0, min(max(curve$grp) * 1.5, max(grp.proj, na.rm = T)))
  } else {
    xlim <- c(0, xmax)
  }
  ylim <- range(curve$reach, reach.proj, reach.combined)  # range of the y axis
  plot(curve$grp, curve$reach, xlab = "TRP", ylab = "Reach",
       xlim = xlim, ylim = ylim, cex = 0.5, type = 'b')
  lines(grp.proj, reach.proj, col = 2) 
  # add a dashed line for the combined reach
  abline(h = reach.combined, lty = 2, col = 3)  

 }


InterpolateEstimate <- function(curve, reach.tv, reach.combined) {
  # Interpolate the curve to find the delta GRPs needed on TV to
  # deliver the reach points equal to the online incremental reach
  max.GRP.ID <- which.max(curve$grp)
  grp.maximal <- curve$grp[max.GRP.ID]
  reach.maximal <- curve$reach[max.GRP.ID]
  reach.start <- reach.tv - (reach.combined - reach.tv)
  index <- which.max(curve$reach >= reach.start)
  if (reach.start < 0 || index <= 1) {
    delta <- NA
  } else {
    grp.start <- curve$grp[index] - (curve$grp[index] - curve$grp[index - 1]) /
      (curve$reach[index] - curve$reach[index - 1]) *
        (curve$reach[index] - reach.start)
    delta <- grp.maximal - grp.start
  }
  return(delta)
}
